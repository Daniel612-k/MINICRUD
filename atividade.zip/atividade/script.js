let itens = [];
let editandoIndex = null;

function adicionarItem() {
    const input = document.getElementById('itemInput');
    const texto = input.value.trim();
    
    if (texto === '') {
        mostrarFeedback('Digite uma tarefa!');
        return;
    }
    
    if (editandoIndex !== null) {
        itens[editandoIndex] = texto;
        editandoIndex = null;
        mostrarFeedback('Tarefa atualizada!');
    } else {
        itens.push(texto);
        mostrarFeedback('Tarefa adicionada! ✅');
    }
    
    input.value = '';
    salvarLocalStorage();
    listarItens();
}

function listarItens() {
    const lista = document.getElementById('listaItens');
    lista.innerHTML = '';
    
    itens.forEach((item, index) => {
        const li = document.createElement('li');
        
        const span = document.createElement('span');
        span.textContent = item;
        
        const divBotoes = document.createElement('div');
        divBotoes.className = 'botoes';
        
        const btnEditar = document.createElement('button');
        btnEditar.textContent = 'Editar';
        btnEditar.className = 'editar';
        btnEditar.onclick = () => editarItem(index);
        
        const btnExcluir = document.createElement('button');
        btnExcluir.textContent = 'Excluir';
        btnExcluir.className = 'excluir';
        btnExcluir.onclick = () => removerItem(index);
        
        divBotoes.appendChild(btnEditar);
        divBotoes.appendChild(btnExcluir);
        
        li.appendChild(span);
        li.appendChild(divBotoes);
        
        lista.appendChild(li);
    });
}

function removerItem(index) {
    itens.splice(index, 1);
    salvarLocalStorage();
    listarItens();
    mostrarFeedback('Tarefa removida!');
}

function editarItem(index) {
    const input = document.getElementById('itemInput');
    input.value = itens[index];
    input.focus();
    editandoIndex = index;
}

function salvarLocalStorage() {
    localStorage.setItem('itensTarefas', JSON.stringify(itens));
}

function carregarLocalStorage() {
    const itensSalvos = localStorage.getItem('itensTarefas');
    if (itensSalvos) {
        itens = JSON.parse(itensSalvos);
    }
    listarItens();
}

function mostrarFeedback(mensagem) {
    const feedback = document.getElementById('feedback');
    feedback.textContent = mensagem;
    feedback.classList.add('mostrar');
    
    setTimeout(() => {
        feedback.classList.remove('mostrar');
    }, 2000);
}

// Inicializar a aplicação
carregarLocalStorage();